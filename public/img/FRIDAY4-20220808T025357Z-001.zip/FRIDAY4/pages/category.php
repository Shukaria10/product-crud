<?php include "header.php"; ?>

<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <img src="assets/img/images.jpg" alt="" class="card-img-top" style="height: 250px;">
                    <div class="card-body">
                        <h5>Product Name</h5>
                        <p>tk.650</p>
                        <hr/>
                        <a href="" class="btn btn-success">Details</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>



<?php include "footer.php"; ?>